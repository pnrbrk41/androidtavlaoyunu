# androidtavlaoyunu
androidtavlaoyunu
Bitirme projesi olarak Unity derleyicisiyle hem Android hem de IOS işletim sisteminde çalışacak şekilde kodlar yazılmıştır.Ağırlıklı Javascriptlerden yararlanılmıştır. Aynı ağ üzerinde karşılıklı online olarak oynanmaktadır bu oyun.
